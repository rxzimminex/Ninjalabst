# ninjaLabs

Projeto estilo Beacons com cadastro de usuários, páginas públicas e editor de links.

## Como usar

1. Configure o MongoDB no arquivo `.env`
2. Rode o backend:
```bash
cd backend
npm install
npm run dev
```
3. Rode o frontend:
```bash
cd frontend
npm install
npm run dev
```
