# Backend - ninjaLabs

Node.js + Express + MongoDB structure goes here.